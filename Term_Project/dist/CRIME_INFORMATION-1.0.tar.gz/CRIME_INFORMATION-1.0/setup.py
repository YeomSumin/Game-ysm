from distutils.core import setup

setup(name='CRIME_INFORMATION',
      version='1.0',
      py_modules=['internetbook'],
      py_modules2=['xmlbook'],
      )